G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-04-21T23:04:31+02:00*
G04 #@! TF.ProjectId,wings,77696e67-732e-46b6-9963-61645f706362,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-04-21 23:04:31*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRotRect*
0 Rectangle, with rotation*
0 The origin of the aperture is its center*
0 $1 length*
0 $2 width*
0 $3 Rotation angle, in degrees counterclockwise*
0 Add horizontal line*
21,1,$1,$2,0,0,$3*%
G04 Aperture macros list end*
%ADD10RotRect,2.006600X7.391400X7.000000*%
%ADD11RotRect,1.700000X1.700000X170.000000*%
%ADD12C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,B2*
X-10757406Y2820018D03*
X10091820Y5379982D03*
G04 #@! TD*
D11*
G04 #@! TO.C,TP1*
X-21729134Y899999D03*
D12*
X-19227721Y458933D03*
G04 #@! TD*
M02*
